Since OPAs are used to inform future work and are internal to the organization, they can be updated continuously throughout the project as knowledge about the project is understood.

The organizational  knowledge bases of a project will store and retrieve important information regarding various factors:
- Configuration management knowledge repositories,
- Financial data repositories
- Historical information and lessons learned knowledge repositories
- Issues and defect management data repositories
- Data repositories for metric used to collect and make available measurement data on processes and products
- Project files from previous projects