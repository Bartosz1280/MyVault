The simplest type of organizational structure.

It presumes flat reporting and a large number of employees for each manager. The interactions between employees tend to be equal in terms of authority.