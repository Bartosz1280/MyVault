
Organizational systems play a significant role in the life cycle of the project.

System factors can impact the:
- power
- influence
- interests
- competencies
- political capabilities of the people

