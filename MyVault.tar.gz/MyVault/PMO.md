Project management office (PMO) - an organizational structure that standardizes project-related governance, process and facilitates, the sharing of resources, methodologies, and tools and techniques, across a department or the entire organization.

Its role is to :
- support strategic alignment
- liaison between an organization's portfolios, programs, projects and organization's measurement system.

Responsibilities may range from providing project management support functions to the direct management of one or more projects.

PMO may act as a group of stakeholders, an may also support project managers.

PMO varies in the degree of influence it has on a project:

| PMO is .. | Provides | Control level|
|  --- | --- | --- |
| Supportive | Consultative role | Low |
| Controlling | Support/Requires compliance | Medium |
| Directive | Takes control/ Manages projects | High |
