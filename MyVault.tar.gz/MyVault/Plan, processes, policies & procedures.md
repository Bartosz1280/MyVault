Not update as a results of the project work.

Established by the project management office.

Can only be updated by following organizational policies.

Organization's processes and policies are grouped into three categories

1. **Initiating and Planning:**
	- Guidelines for tailoring organization's standard processes and procedures to satisfy the needs of the project
	- Specific organizational standards such as its policies
	- Product and project life cycles, and methods and procedures
	- Templates
	- Preapproved supplier lists and various types of  contractual agreements.

2. **Executing, Monitoring, and Controlling:**
	- Change control
	- Traceability matrices
	- Financial controls procedures
	- Issues and defect management procedures
	- Resource availability control and assignment management
	- Organizational communication requirements
	- Procedures for prioritizing, approving, and issuing work authorizations
	- Templates
	- Standardized guidelines, work instructions, proposal evaluation criteria, and performance measurement criteria
	- Product, service, or result verification and validation procedures.
3. **Closing:**
	- Project closure guidelines or requirements