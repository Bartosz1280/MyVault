Organizational arrangements designed to determine and influence the behavior of the organization's members.

It considers:
- people
- roles
- structures
- policies

Requires providing direction and oversight through data and feedback.

Acts as the framework that exercises authority in an organization.

This framework may includes:
- rules
- policies
- procedures
- norms within the organization

Frameworks can influence:
- How the objectives of an organization are set and achieved..
- How risk is monitored and assessed
- How performance is optimized

Project governance refers to the framework that guides project management activities in order to meet organizational, strategic and operational goals.

A governance framework should be tailored to the needs of the organization in order to be effective.