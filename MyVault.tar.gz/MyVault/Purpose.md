A system a collection of various components that produce results not obtainable by the individual components alone.

A system component as identifiable elements that provides a particular function or group of related functions.

Interaction of systems components within the company creates organizational culture and capabilities.

Comprised of multiple factors that creates a unique structure and can impact the project operating in that system.

Organizational systems determines:
- power
- influence
- interests
- competence
- political capabilities

Projects operates within the boundaries imposed by the organization-through its structure and governance framework.

When changes occur between the system and the environment, changes occur within the components themselves.

To operate effectively, you need ti understand where responsibility, accountability and authority reside within the organization.

This understanding helps you successfully complete the project, because any changes to the system or its components will affect the project, and you must adjust for  these changes.