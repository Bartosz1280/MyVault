Project exists and operate in enviroments that may have an influence on them.

Theses influences can have either a **favorable** or **unfavorable** impact on the project.

Types of influences:
[[Enterprise environmental factors (EEFs)]]
[[Organizational process assets]]

[[Organizational process assets (OPAs)]]

[[Organizational systems]] play a significant role in the life cycle of the project

[[Purpose]] of organizational systems.

[[Governance]] is organizational arrangements designed to determine and influence the behavior of the organization's members.

[[Management Elements]] are components that dictate the principles and functions of management in an organization.

[[Organizational Structures Types]] define the way different responsibilities are allocated between different entities of the organization.