As a project manager you will work with stakeholders to determine the appropriate generally recognized good practices for every project you take on.

It is primarily your duty to determine the appropriate combination of processes, inputs, tools, techniques, outputs and life cycle phases to manage a project.

Determining the right match for your project is called tailoring your project accordingly.

As project manager, you will usually be involved in a project from its initiation through its closing.

Sometimes, you will be involved in a needs analysis before project initiation.

A needs analysis involves consulting with executive and business leaders on ideas that advance strategic objectives, improve organizational performance, or meet customer needs.

Sometimes, you may be involved after a project closes to better analyze the business benefits realized from the project.

As project manager your role is different than a functional manager, who provides management for a business unit, and an operational manager, who is responsible for the efficiency of operations.