Originate from the environment outside the project and often outside the enterprise

May include:
- Marketplace
- Infrastructure
- Legal regulations

Can be divided into two [[EEFs internal to the organization]] and [[EEFs external to the orgnization]]
