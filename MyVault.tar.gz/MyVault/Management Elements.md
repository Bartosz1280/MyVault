
Components that dictate the principles and functions of management in an organization.

The management elements are allocated to people in the organization according to its governance framework and the organizational structure type.

Key functions and principles of management may include:
- The authority given to perform work
- The division of work using specialized skills and availability to perform work
- Any discipline of action
- Being paid fairly for work performed
- Demonstrating that the goals of the organization take precedence over individual goals.