An organizational structure type where people are organized in entities based on their specialties (like marketing, IT, and procurement) and entities (like departments or teams).

Managers control and decide on most of the operational aspects. Also, managers are the ones coordinating any projects.