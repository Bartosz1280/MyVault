- **Social and cultural influences and issues**
	- Political climate, codes of conduct, ethics and perceptions
* **Legal Restrictions**
	Country or local laws and regulations related to security, data protection, business conduct, employment, and procurement.
* **Commercial databases**
	* Benchmarking results, standardized cost estimating data, industry risk study information, and risk databases.
* **Academic research**
	* Industry studies, publications, and benchmarking results
* **Government or industry standards**
	* regulatory agency regulations and standards related to products, production, environment, quality and workmanship.
* **Financial considerations**
	* currency exchange rates, interest rates inflation rates, tariffs and geographic location
* **Physical environmental elements**
	* working conditions, weather and constraints