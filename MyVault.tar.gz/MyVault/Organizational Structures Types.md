
Organizational structures define the way different responsibilities are allocated between different entities of the organization.

The structure of an organization can be different depending on factors like the organizations' objectives, strategy or industry.

Each organization considers numerous factors fore inclusion in its organizational structure.

Each factor has a different level of importance in the final analysis.

The combination of the factors, its value, and relative importance provides the organization's decision makers with the right information for inclusion.

The final structure for a given organization is unique due to the numerous variables to be considered.

Some factors that can be considered include:
- The degree if alignment with organizational objectives
- Specialization capabilities,
- The span of organizational control, efficiency, and effectiveness
- A clear path for the escalation of decisions

There are 10 main types:
[[Hybrid]]
[[Virtual]]
[[Multi-divisional]]
[[Functional (centralized)]]
[[Organic or simple]]
[[Matrix-strong]]
[[Matrix-weak]]
[[Matrix-balanced]]
[[Project-oriented]]
[[PMO]]