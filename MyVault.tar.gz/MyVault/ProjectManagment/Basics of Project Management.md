1 . [[Environment]]
2.[[The Role of project of the project manager]]