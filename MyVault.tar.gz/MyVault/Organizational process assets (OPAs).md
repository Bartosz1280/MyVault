Internal to the organization, and may arise from the organization itself.

Includes things like:
- Plans
- Processes
- Policies & procedures
- Organizational knowledge repositories
- Existing procedures
- Templates