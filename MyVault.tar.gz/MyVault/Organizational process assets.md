The plans, processes, policies, procedures, and knowledge bases specific to an used by the performing organization.

These assets influence the management of the project.

OPAs include any artifact, practice, or knowledge from any or all of the organizations involved in the project.

There are two categories of OPAs:
[[Plan, processes, policies & procedures]]
[[Organizational knowledge repositories]]